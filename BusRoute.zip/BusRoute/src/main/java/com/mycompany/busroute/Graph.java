
package com.mycompany.busroute;
import java.util.*;

class Graph {
    private Map<String, Map<String, Integer>> adjacencyList = new HashMap<>();
    private Map<String, Vertex> verticesMap = new HashMap<>();

    public void addVertex(String name, int x, int y) {
        Vertex vertex = new Vertex(name, x, y);
        verticesMap.put(name, vertex);
        adjacencyList.put(name, new HashMap<>());
    }

    public void addEdge(String source, String destination, int weight) {
        adjacencyList.get(source).put(destination, weight);
        adjacencyList.get(destination).put(source, weight);
    }

    public Map<String, Integer> getNeighbors(String vertex) {
        return adjacencyList.get(vertex);
    }

    public String[] getVertices() {
        return adjacencyList.keySet().toArray(new String[0]);
    }

    public Vertex getVertex(String name) {
        return verticesMap.get(name);
    }
}
