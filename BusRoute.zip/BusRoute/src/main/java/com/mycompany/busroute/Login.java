package com.mycompany.busroute;

import java.util.*;

class Vertex {
    private String name;
    private int x;
    private int y;

    public Vertex(String name, int x, int y) {
        this.name = name;
        this.x = x;
        this.y = y;
    }

    public String getName() {
        return name;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    @Override
    public String toString() {
        return name;
    }
}

class Graph {
    private Map<String, Map<String, Integer>> adjacencyList = new HashMap<>();
    private Map<String, Vertex> verticesMap = new HashMap<>();

    public void addVertex(String name, int x, int y) {
        Vertex vertex = new Vertex(name, x, y);
        verticesMap.put(name, vertex);
        adjacencyList.put(name, new HashMap<>());
    }

    public void addEdge(String source, String destination, int weight) {
        adjacencyList.get(source).put(destination, weight);
        adjacencyList.get(destination).put(source, weight);
    }

    public void deleteVertex(String name) {
        verticesMap.remove(name);
        adjacencyList.remove(name);
        for (Map<String, Integer> edges : adjacencyList.values()) {
            edges.remove(name);
        }
    }

    public void deleteEdge(String source, String destination) {
        adjacencyList.get(source).remove(destination);
        adjacencyList.get(destination).remove(source);
    }

    public void updateVertex(String name, int x, int y) {
        if (verticesMap.containsKey(name)) {
            verticesMap.put(name, new Vertex(name, x, y));
        }
    }

    public void updateEdge(String source, String destination, int weight) {
        if (adjacencyList.containsKey(source) && 
                adjacencyList.get(source).containsKey(destination)) {
            adjacencyList.get(source).put(destination, weight);
            adjacencyList.get(destination).put(source, weight);
        }
    }

    public Map<String, Integer> getNeighbors(String vertex) {
        return adjacencyList.get(vertex);
    }

    public String[] getVertices() {
        return adjacencyList.keySet().toArray(new String[0]);
    }

    public List<Vertex> getVerticesList() {
        return new ArrayList<>(verticesMap.values());
    }

    public Vertex getVertex(String name) {
        return verticesMap.get(name);
    }
}

class Login {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("---------Welcome!-----------\n\n");
        System.out.print("Enter 'user' for user role, 'developer' for developer role: ");
        String role = scanner.nextLine();

        if ("user".equalsIgnoreCase(role)) {
            userRole();
        } else if ("dev".equalsIgnoreCase(role)) {
            developerRole();
        } else {
            System.out.println("Invalid role. Exiting.");
        }
    }

    private static void userRole() {
        Graph graph = initializeGraph();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Available Routes:");
        String[] vertices = graph.getVertices();
        for (String vertex : vertices) {
            System.out.println(vertex);
        }

        System.out.print("Enter starting point: ");
        String startVertex = scanner.nextLine();

        if (!Arrays.asList(vertices).contains(startVertex)) {
            System.out.println("Invalid starting route. Exiting.");
            return;
        }

        System.out.print("Enter destination route: ");
        String destinationVertex = scanner.nextLine();

        if (!Arrays.asList(vertices).contains(destinationVertex)) {
            System.out.println("Invalid destination route. Exiting.");
            return;
        }

        Map<String, Integer> shortestPath = dijkstra(graph, startVertex, 
                destinationVertex);

        if (shortestPath.containsKey(destinationVertex)) {
            int cost = shortestPath.get(destinationVertex);
            System.out.println("Shortest path from " + startVertex + " to " 
                    + destinationVertex + ": " + cost + " km");

            List<String> path = constructPath(graph, shortestPath, 
                    startVertex, destinationVertex);
            System.out.println("Directions:");

            for (int i = 0; i < path.size() - 1; i++) {
                String currentVertex = path.get(i);
                String nextVertex = path.get(i + 1);
                int edgeWeight = graph.getNeighbors(
                        currentVertex).get(nextVertex);

                System.out.println("Go from " + currentVertex + " to " 
                        + nextVertex + " (Distance: " + edgeWeight + " km)");
            }
        } else {
            System.out.println("No path found from " + startVertex + 
                    " to " + destinationVertex);
        }
    }

    private static void developerRole() {
        Graph graph = initializeGraph();
        Scanner scanner = new Scanner(System.in);
        boolean exitDeveloper = false;

        while (!exitDeveloper) {
            System.out.println("\nDeveloper Options:");
            System.out.println("1. Add Routes");
            System.out.println("2. Add Edge");
            System.out.println("3. Delete Routes");
            System.out.println("4. Delete Edge");
            System.out.println("5. Update Routes");
            System.out.println("6. Update Edge");
            System.out.println("7. Display Graph");
            System.out.println("8. Exit Developer Mode");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addVertex(graph);
                    break;
                case 2:
                    addEdge(graph);
                    break;
                case 3:
                    deleteVertex(graph);
                    break;
                case 4:
                    deleteEdge(graph);
                    break;
                case 5:
                    updateVertex(graph);
                    break;
                case 6:
                    updateEdge(graph);
                    break;
                case 7:
                    displayGraph(graph);
                    break;
                case 8:
                    exitDeveloper = true;
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private static void addVertex(Graph graph) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Route name: ");
        String name = scanner.nextLine();
        System.out.print("Enter X coordinate: ");
        int x = scanner.nextInt();
        System.out.print("Enter Y coordinate: ");
        int y = scanner.nextInt();

        graph.addVertex(name, x, y);
        System.out.println("New Bus Route added successfully.");
    }

    private static void addEdge(Graph graph) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter source route: ");
        String source = scanner.nextLine();
        System.out.print("Enter destination route: ");
        String destination = scanner.nextLine();
        System.out.print("Enter edge weight(Distances): ");
        int weight = scanner.nextInt();

        graph.addEdge(source, destination, weight);
        System.out.println("Edge added successfully.");
    }

    private static void deleteVertex(Graph graph) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter route name to delete: ");
        String name = scanner.nextLine();

        graph.deleteVertex(name);
        System.out.println("Bus route deleted successfully.");
    }

    private static void deleteEdge(Graph graph) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter source route: ");
        String source = scanner.nextLine();
        System.out.print("Enter destination route: ");
        String destination = scanner.nextLine();

        graph.deleteEdge(source, destination);
        System.out.println("Distance between routes deleted successfully.");
    }

    private static void updateVertex(Graph graph) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a route name to update: ");
        String name = scanner.nextLine();
        System.out.print("Enter new X coordinate: ");
        int x = scanner.nextInt();
        System.out.print("Enter new Y coordinate: ");
        int y = scanner.nextInt();

        graph.updateVertex(name, x, y);
        System.out.println("Bus Route updated successfully.");
    }

    private static void updateEdge(Graph graph) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter source route: ");
        String source = scanner.nextLine();
        System.out.print("Enter destination route: ");
        String destination = scanner.nextLine();
        System.out.print("Enter new distance(edge) weight: ");
        int weight = scanner.nextInt();

        graph.updateEdge(source, destination, weight);
        System.out.println("Distance between routes updated successfully.");
    }

    private static List<String> constructPath(Graph graph, Map<String, Integer> 
            shortestPath, String startVertex, String destinationVertex) {
        List<String> path = new ArrayList<>();
        String currentVertex = destinationVertex;

        while (!currentVertex.equals(startVertex)) {
            path.add(currentVertex);
            String nextVertex = null;
            int minDistance = Integer.MAX_VALUE;

            for (Map.Entry<String, Integer> neighbor : graph.getNeighbors(
                    currentVertex).entrySet()) {
                if (shortestPath.containsKey(neighbor.getKey())) {
                    int neighborDistance = shortestPath.get(neighbor.getKey());
                    if (neighborDistance < minDistance) {
                        nextVertex = neighbor.getKey();
                        minDistance = neighborDistance;
                    }
                }
            }

            if (nextVertex == null) {
                break;
            }

            currentVertex = nextVertex;
        }

        Collections.reverse(path);
        return path;
    }

    static Map<String, Integer> dijkstra(Graph graph, String startVertex, 
            String destinationVertex) {
        Map<String, Integer> distance = new HashMap<>();
        PriorityQueue<String[]> minHeap = new PriorityQueue<>
        (Comparator.comparingInt(a -> Integer.parseInt(a[1])));

        distance.put(startVertex, 0);
        minHeap.offer(new String[]{startVertex, "0"});

        while (!minHeap.isEmpty()) {
            String[] current = minHeap.poll();
            String currentVertex = current[0];
            int currentDistance = Integer.parseInt(current[1]);

            if (currentDistance > distance.getOrDefault(currentVertex, 
                    Integer.MAX_VALUE)) {
                continue;
            }

            for (Map.Entry<String, Integer> neighbor : graph.getNeighbors(
                    currentVertex).entrySet()) {
                String nextVertex = neighbor.getKey();
                int newDistance = currentDistance + neighbor.getValue();

                if (newDistance < distance.getOrDefault(nextVertex, 
                        Integer.MAX_VALUE)) {
                    distance.put(nextVertex, newDistance);
                    minHeap.offer(new String[]{nextVertex, 
                        String.valueOf(newDistance)});
                }
            }
        }

        return distance;
    }

    private static Graph initializeGraph() {
        Graph graph = new Graph();

        graph.addVertex("GUB", 50, 50);
        graph.addVertex("kanchan", 60, 40);
        graph.addVertex("kaladi", 70, 30);
        graph.addVertex("mirpur", 40, 60);
        graph.addVertex("rupsi", 30, 70);
        graph.addVertex("borpa", 80, 20);
        graph.addVertex("gausia", 90, 10);
        graph.addVertex("bisshoroad", 45, 55);
        graph.addVertex("konapara", 65, 35);
        graph.addVertex("staff quarter", 75, 25);
        graph.addVertex("signboard", 35, 65);
        graph.addVertex("rayerbag", 25, 75);
        graph.addVertex("jatrabari", 85, 15);
        graph.addVertex("gulistan", 95, 5);
        graph.addVertex("khilgaon", 55, 45);
        graph.addVertex("rampura", 65, 35);
        graph.addVertex("bashundhara", 75, 25);
        graph.addVertex("kuril", 85, 15);
        graph.addVertex("narsingdhi", 100, 0);
        graph.addVertex("sonargaon", 10, 90);

        graph.addEdge("GUB", "kanchan", 4);
        graph.addEdge("GUB", "kaladi", 2);
        graph.addEdge("kanchan", "mirpur", 21);
        graph.addEdge("mirpur", "rupsi", 30);
        graph.addEdge("kanchan", "rupsi", 18);
        graph.addEdge("rupsi", "borpa", 6);
        graph.addEdge("borpa", "gausia", 7);
        graph.addEdge("borpa", "bisshoroad", 11);
        graph.addEdge("gausia", "bisshoroad", 17);
        graph.addEdge("bisshoroad", "konapara", 5);
        graph.addEdge("konapara", "staff quarter", 3);
        graph.addEdge("staff quarter", "signboard", 4);
        graph.addEdge("signboard", "rayerbag", 3);
        graph.addEdge("rayerbag", "jatrabari", 4);
        graph.addEdge("jatrabari", "gulistan", 5);
        graph.addEdge("gulistan", "khilgaon", 9);
        graph.addEdge("khilgaon", "rampura", 5);
        graph.addEdge("rampura", "bashundhara", 8);
        graph.addEdge("bashundhara", "kuril", 4);
        graph.addEdge("kuril", "narsingdhi", 27);
        graph.addEdge("narsingdhi", "sonargaon", 11);

        return graph;
    }

    private static void displayGraph(Graph graph) {
        System.out.println("\nGraph Details:");
        for (Vertex vertex : graph.getVerticesList()) {
            System.out.println("Vertex: " + vertex.getName() + ", Coordinates: (" +
                    vertex.getX() + ", " + vertex.getY() + ")");
            System.out.println("Edges: " + graph.getNeighbors
        (vertex.getName()));
            System.out.println();
        }
    }
}
