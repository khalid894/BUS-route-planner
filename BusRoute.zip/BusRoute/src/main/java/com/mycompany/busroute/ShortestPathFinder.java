
package com.mycompany.busroute;

import java.util.*;

public class ShortestPathFinder {
    public static void main(String[] args) {
        Graph graph = initializeGraph();

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter starting vertex: ");
        String startVertex = scanner.nextLine();
        System.out.print("Enter destination vertex: ");
        String destinationVertex = scanner.nextLine();

        if (!Arrays.asList(graph.getVertices()).contains(startVertex) || 
            !Arrays.asList(graph.getVertices()).contains(destinationVertex)) {
            System.out.println("Invalid search. One or both vertices do not exist.");
            return;
        }

        Map<String, Integer> shortestPath = dijkstra(graph, startVertex,
                destinationVertex);

        if (shortestPath.containsKey(destinationVertex)) {
            int cost = shortestPath.get(destinationVertex);
            System.out.println("Shortest path from " + startVertex + " to "
                    + destinationVertex + ": " + cost + " km");
        } else {
            System.out.println("No path found from " + startVertex + " to "
                    + destinationVertex);
        }
    }

    private static Graph initializeGraph() {
        Graph graph = new Graph();

        // Add vertices with coordinates
        graph.addVertex("GUB", 50, 50);
        graph.addVertex("kanchan", 60, 40);
        graph.addVertex("kaladi", 70, 30);
        graph.addVertex("mirpur", 40, 60);
        graph.addVertex("rupsi", 30, 70);
        graph.addVertex("borpa", 80, 20);
        graph.addVertex("gausia", 90, 10);
        graph.addVertex("bisshoroad", 45, 55);
        graph.addVertex("konapara", 65, 35);
        graph.addVertex("staff quarter", 75, 25);
        graph.addVertex("signboard", 35, 65);
        graph.addVertex("rayerbag", 25, 75);
        graph.addVertex("jatrabari", 85, 15);
        graph.addVertex("gulistan", 95, 5);
        graph.addVertex("khilgaon", 55, 45);
        graph.addVertex("rampura", 65, 35);
        graph.addVertex("bashundhara", 75, 25);
        graph.addVertex("kuril", 85, 15);
        graph.addVertex("narsingdhi", 100, 0);
        graph.addVertex("sonargaon", 10, 90);

        // Add fixed edges with weighted costs
        graph.addEdge("GUB", "kanchan", 4);
        graph.addEdge("GUB", "kaladi", 2);
        graph.addEdge("kanchan", "mirpur", 21);
        graph.addEdge("mirpur", "rupsi", 30);
        graph.addEdge("kanchan", "rupsi", 18);
        graph.addEdge("rupsi", "borpa", 6);
        graph.addEdge("borpa", "gausia", 7);
        graph.addEdge("borpa", "bisshoroad", 11);
        graph.addEdge("gausia", "bisshoroad", 17);
        graph.addEdge("bisshoroad", "konapara", 5);
        graph.addEdge("konapara", "staff quarter", 3);
        graph.addEdge("staff quarter", "signboard", 4);
        graph.addEdge("signboard", "rayerbag", 3);
        graph.addEdge("rayerbag", "jatrabari", 4);
        graph.addEdge("jatrabari", "gulistan", 5);
        graph.addEdge("gulistan", "khilgaon", 9);
        graph.addEdge("khilgaon", "rampura", 5);
        graph.addEdge("rampura", "bashundhara", 8);
        graph.addEdge("bashundhara", "kuril", 4);
        graph.addEdge("kuril", "narsingdhi", 27);
        graph.addEdge("narsingdhi", "sonargaon", 11);

        return graph;
    }

    static Map<String, Integer> dijkstra(Graph graph, String startVertex, 
            String destinationVertex) {
        Map<String, Integer> distance = new HashMap<>();
        PriorityQueue<String[]> minHeap = new PriorityQueue<>
        (Comparator.comparingInt(a -> Integer.parseInt(a[1])));

        distance.put(startVertex, 0);
        minHeap.offer(new String[]{startVertex, "0"});

        while (!minHeap.isEmpty()) {
            String[] current = minHeap.poll();
            String currentVertex = current[0];
            int currentDistance = Integer.parseInt(current[1]);

            if (currentDistance > distance.getOrDefault
        (currentVertex, Integer.MAX_VALUE)) {
                continue;
            }

            for (Map.Entry<String, Integer> neighbor : graph.getNeighbors
        (currentVertex).entrySet()) {
                String nextVertex = neighbor.getKey();
                int newDistance = currentDistance + neighbor.getValue();

                if (newDistance < distance.getOrDefault(nextVertex, 
                        Integer.MAX_VALUE)) {
                    distance.put(nextVertex, newDistance);
                    minHeap.offer(new String[]{nextVertex, 
                        String.valueOf(newDistance)});
                }
            }
        }

        return distance;
    }
}

